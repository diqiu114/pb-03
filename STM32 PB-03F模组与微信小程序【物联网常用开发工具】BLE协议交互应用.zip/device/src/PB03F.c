#include "PB03F.h"
#include "usart.h"
#include "delay.h"
#include <stdarg.h>
#include "stdlib.h"

struct STRUCT_USART_Fram PB03F_Fram_Record_Struct = { 0 };  //������һ������֡�ṹ��

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(LED_Pin_Periph_Clock, ENABLE);

	GPIO_InitStructure.GPIO_Pin = LED_Pin;             
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     //�����������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(LED_Pin_Port, &GPIO_InitStructure);
}

void msgProcess(void){
	char mag[6] = {0};
	PB03F_Fram_Record_Struct.Data_RX_BUF[PB03F_Fram_Record_Struct.InfBit.FramLength ] = '\0';
	printf("get raw message%s\n",PB03F_Fram_Record_Struct.Data_RX_BUF);
	for(int i = 0; i < PB03F_Fram_Record_Struct.InfBit.FramLength; i ++){
		if(PB03F_Fram_Record_Struct.Data_RX_BUF[i] == 'A' && PB03F_Fram_Record_Struct.Data_RX_BUF[i - 1] == 'A'){
			for(int j = 0; j < 5; j ++){
				mag[j] = PB03F_Fram_Record_Struct.Data_RX_BUF[i + j - 1];
			}
			printf("get message %s and break\n",mag);
			break;
		}			
	}
	if(mag[2] == '0'){
		LED_Pin_SetH;
		printf("turn off the light");
	}
	else if(mag[2] == '1'){
		LED_Pin_SetL;
		printf("turn on the light");
	}
	for(int a = 0; a < PB03F_Fram_Record_Struct.InfBit.FramLength; a ++){
		PB03F_Fram_Record_Struct.Data_RX_BUF[a] = '\0';
	}
	PB03F_Fram_Record_Struct.InfBit.FramLength = 0; //���½����µ����ݰ�
}

void PB03F_Init(u32 bound)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(PB03F_RST_Pin_Periph_Clock, ENABLE);

	GPIO_InitStructure.GPIO_Pin = PB03F_RST_Pin;             
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     //�����������
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;    
	GPIO_Init(PB03F_RST_Pin_Port, &GPIO_InitStructure);

	uart2_Init(bound); 
	PB03F_Rst();
	PB03F_Fram_Record_Struct.messageProcess = &msgProcess;
}

//��PB03Fģ�鷢��ATָ��
// cmd �����͵�ָ��
// ack1,ack2;�ڴ�����Ӧ��ΪNULL��������Ӧ������Ϊ���߼���ϵ
// time �ȴ���Ӧʱ��
//����1���ͳɹ��� 0ʧ��
bool PB03F_Send_AT_Cmd(char *cmd,char *ack1,char *ack2,u32 time)
{ 
    PB03F_Fram_Record_Struct .InfBit .FramLength = 0; //���½����µ����ݰ�
	if(strcmp(cmd,"+++") == 0)	
		PB03F_USART("%s", cmd);
	else
		PB03F_USART("%s\r\n", cmd);
    if(ack1==0&&ack2==0)     //����Ҫ��������
    {
		return true;
    }
	printf("delay some time to get receive data\r\n");
    delay_ms(time);   //�ṩ�㹻��ʱ�����ڽ������ݣ������ݽ��ղ�����uart�ж�usart.h --> USART2_IRQHandler(void) ����ɣ�
    PB03F_Fram_Record_Struct.Data_RX_BUF[PB03F_Fram_Record_Struct.InfBit.FramLength ] = '\0';
		
    printf("PB03F_data:%s",PB03F_Fram_Record_Struct .Data_RX_BUF);
    if(ack1!=0&&ack2!=0)
    {
        return ( ( bool ) strstr ( PB03F_Fram_Record_Struct .Data_RX_BUF, ack1 ) || 	//��ѯ
                         ( bool ) strstr ( PB03F_Fram_Record_Struct .Data_RX_BUF, ack2 ) );
    }
    else if( ack1 != 0 )  //strstr(s1,s2);���s2�Ƿ�Ϊs1��һ���֣��Ƿ��ظ�λ�ã����򷵻�false����ǿ��ת��Ϊbool������
        return ( ( bool ) strstr ( PB03F_Fram_Record_Struct .Data_RX_BUF, ack1 ) );

    else if( ack2 != 0 )
        return ( ( bool ) strstr ( PB03F_Fram_Record_Struct .Data_RX_BUF, ack2 ) );
	else
		return false;
}


//��λ����
void PB03F_Rst(void)
{
    PB03F_RST_Pin_SetL;
    delay_ms(500); 
    PB03F_RST_Pin_SetH;
}


//���ͻָ�����Ĭ������ָ�ģ��ָ��ɳ�������
bool PB03F_AT_Test(void)
{
    char count=0;
    delay_ms(1000); 
    while(count < 10)
    {
		printf("AT Test\r\n");
        if(PB03F_Send_AT_Cmd("AT","OK",NULL,500))
        {
            printf("OK\r\n");
            return true;
        }
        ++ count;
    }
	return false;
}

//PB03F ����ģ���BLEģʽ
//AT+BLEMODE=mode		mode��0���ӻ�ģʽ����   1��������ģʽ����   2��iBeacon��    9���ر�������
//���óɹ�����OK ��֮ ERROR
bool PB03F_Set_BLEMode ( uint8_t mode, bool stepSwitch)
{
    if(stepSwitch){
		char cStr [20];
		sprintf ( cStr, "AT+BLEMODE=%d", mode);
		if(PB03F_Send_AT_Cmd ( cStr, "OK", 0, 1500 ))
			return true;
		else
			return false;
	}else
		return false;
}


//PB03F ���������㲥����
//AT+BLENAME=BLEName
//���óɹ�����OK ��֮ERROR
bool PB03F_Set_BLEName( char * BLEName, bool stepSwitch)
{
    if(stepSwitch){
		char cStr [20];
		sprintf ( cStr, "AT+BLENAME=%s", BLEName );
		if(PB03F_Send_AT_Cmd ( cStr, "OK", 0, 200 )){
			return true;
		}else
			return false;
	}else
		return false;
}

bool PB03F_transmission_exit(void){
	if(PB03F_Send_AT_Cmd ( "+++", "OK", 0, 100 ))
			return true;
		else
			return false;
}

void PB03F_Set_Slave_Broadcast(void){
	bool switchFlag = 0;
	switchFlag = PB03F_AT_Test();
	switchFlag = PB03F_Set_BLEMode (0,switchFlag);
	switchFlag = PB03F_Set_BLEName("ai-thinker",switchFlag);
}



static char *itoa( int value, char *string, int radix )
{
    int     i, d;
    int     flag = 0;
    char    *ptr = string;

    /* This implementation only works for decimal numbers. */
    if (radix != 10)
    {
        *ptr = 0;
        return string;
    }

    if (!value)
    {
        *ptr++ = 0x30;
        *ptr = 0;
        return string;
    }

    /* if this is a negative value insert the minus sign. */
    if (value < 0)
    {
        *ptr++ = '-';

        /* Make the value positive. */
        value *= -1;

    }

    for (i = 10000; i > 0; i /= 10)
    {
        d = value / i;

        if (d || flag)
        {
            *ptr++ = (char)(d + 0x30);
            value -= (d * i);
            flag = 1;
        }
    }

    /* Null terminate the string. */
    *ptr = 0;

    return string;

} /* NCL_Itoa */

void USART_printf ( USART_TypeDef * USARTx, char * Data, ... )
{
    const char *s;
    int d;   
    char buf[16];


    va_list ap;
    va_start(ap, Data);

    while ( * Data != 0 )     // �ж������Ƿ񵽴������
    {                                         
        if ( * Data == 0x5c )  //'\'
        {                                     
            switch ( *++Data )
            {
                case 'r':                                     //�س���
                USART_SendData(USARTx, 0x0d);
                Data ++;
                break;

                case 'n':                                     //���з�
                USART_SendData(USARTx, 0x0a);   
                Data ++;
                break;

                default:
                Data ++;
                break;
            }            
        }

        else if ( * Data == '%')
        {                                     
            switch ( *++Data )
            {               
                case 's':                                         //�ַ���
                s = va_arg(ap, const char *);
                for ( ; *s; s++) 
                {
                    USART_SendData(USARTx,*s);
                    while( USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET );
                }
                Data++;
                break;

                case 'd':           
                    //ʮ����
                d = va_arg(ap, int);
                itoa(d, buf, 10);
                for (s = buf; *s; s++) 
                {
                    USART_SendData(USARTx,*s);
                    while( USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET );
                }
                     Data++;
                     break;
                default:
                     Data++;
                     break;
            }        
        }
        else USART_SendData(USARTx, *Data++);
        while ( USART_GetFlagStatus ( USARTx, USART_FLAG_TXE ) == RESET );

    }
}
