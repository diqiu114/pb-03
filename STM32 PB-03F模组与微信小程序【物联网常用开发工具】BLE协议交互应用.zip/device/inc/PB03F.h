#ifndef __PB03F_H
#define __PB03F_H			   
#include "stm32f10x.h"

#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#if defined ( __CC_ARM   )
#pragma anon_unions
#endif

//PB03Fģʽѡ��
typedef enum
{
    STA,
    AP,
    STA_AP  
}ENUM_Net_ModeTypeDef;

typedef enum
{
	RF_Least_Func=0,
	RF_Full_Func=1,
	RF_OFF=4
}RF_Switch;

//��������
typedef enum{
	Register_Forbid=0,
	Register_status,
	Register_status_Location,
	Register_status_Location_failResaon,
	Register_status_Location_timer,
	Register_status_Location_failResaon_timer
} Attach_Net_Mode;

#define PB03F_RST_Pin          GPIO_Pin_4    //��λ�ܽ�
#define PB03F_RST_Pin_Port     GPIOA    //��λ 
#define PB03F_RST_Pin_Periph_Clock  RCC_APB2Periph_GPIOA       //��λʱ��

#define PB03F_RST_Pin_SetH     GPIO_SetBits(PB03F_RST_Pin_Port,PB03F_RST_Pin)
#define PB03F_RST_Pin_SetL     GPIO_ResetBits(PB03F_RST_Pin_Port,PB03F_RST_Pin)

#define LED_Pin          GPIO_Pin_12    //��λ�ܽ�
#define LED_Pin_Port     GPIOB    //��λ 
#define LED_Pin_Periph_Clock  RCC_APB2Periph_GPIOA       //��λʱ��

#define LED_Pin_SetH     GPIO_SetBits(LED_Pin_Port,LED_Pin)
#define LED_Pin_SetL     GPIO_ResetBits(LED_Pin_Port,LED_Pin)

#define PB03F_USART(fmt, ...)  USART_printf (USART2, fmt, ##__VA_ARGS__)    
#define PC_USART(fmt, ...)       printf(fmt, ##__VA_ARGS__)       //���Ǵ��ڴ�ӡ����������1��ִ��printf����Զ�ִ��fput�������ض�����printf��

#define RX_BUF_MAX_LEN 1024       //����ֽ���
extern struct STRUCT_USART_Fram   //����֡�ṹ��
{
    char Data_RX_BUF[RX_BUF_MAX_LEN];
    union 
    {
        __IO u16 InfAll;
        struct 
        {
            __IO u16 FramLength       :15;                               // 14:0 
            __IO u16 FramFinishFlag   :1;                                // 15 
        }InfBit;
    }; 
	void (*messageProcess)();
}PB03F_Fram_Record_Struct;


//��ʼ����TCP���ܺ���
void PB03F_Init(u32 bound);
void LED_Init(void);
bool PB03F_AT_Test(void);
bool PB03F_Send_AT_Cmd(char *cmd,char *ack1,char *ack2,u32 time);
void PB03F_Rst(void);
bool PB03F_Set_BLEMode ( uint8_t mode, bool stepSwitch);
bool PB03F_Set_BLEName( char * Cline_ID, bool stepSwitch);
bool PB03F_transmission_exit(void);
void PB03F_Set_Slave_Broadcast(void);

void USART_printf( USART_TypeDef * USARTx, char * Data, ... );

#endif
